# Quick Back (Android)

A tiny launcher app intended to be assigned to Motorola Quick Launch. When opened, it asks its enabled AccessibilityService to perform Android's global Back action, then immediately finishes.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Build > Build APK(s).
4. Install the generated APK on the phone.

## One-time setup
1. Open **Quick Back** manually once.
2. Android Accessibility settings will open.
3. Enable **Quick Back** under Downloaded/Installed apps.
4. Return to the app. It will perform Back once as a quick test.
5. In Motorola Settings > Gestures > Quick Launch, choose **Open app > Quick Back**.

## Notes
- Accessibility permission is required because normal Android apps cannot issue the system Back action directly.
- Android/Motorola may show a brief app-launch transition; a literal zero-delay launch is not possible for a third-party app.
- The service does not read screen content, collect data, or use the network.

package in.samayran.quickback

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

class MainActivity : Activity() {
    private var waitingForAccessibility = false
    private var actionSent = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setWindowAnimations(0)
        runBackOrRequestSetup()
    }

    override fun onResume() {
        super.onResume()
        if (waitingForAccessibility && !actionSent && isAccessibilityServiceEnabled()) {
            waitingForAccessibility = false
            performBack()
        }
    }

    private fun runBackOrRequestSetup() {
        if (isAccessibilityServiceEnabled()) {
            performBack()
        } else {
            waitingForAccessibility = true
            Toast.makeText(this, "Enable Quick Back in Accessibility settings, then return here.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun performBack() {
        if (actionSent) return
        val service = QuickBackAccessibilityService.instance
        if (service != null) {
            actionSent = service.performGlobalAction(GLOBAL_ACTION_BACK)
            finish()
            overridePendingTransition(0, 0)
        } else {
            Toast.makeText(this, "Quick Back service is not active. Enable it in Accessibility settings.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            waitingForAccessibility = true
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = "$packageName/${QuickBackAccessibilityService::class.java.name}"
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }
}
